	<div class="footer">
<div class="container-fluid">
	<div class="row">
		<div class="col-md-4">
	      <h3 align="center">Alamat Kami</h3>
	      <table class="table">
	      	<tr>
	      		<td><h4>Lokasi: Jalan Mawar No.47</h4></td>
	      		<td></td>
	      	</tr>
	      	<tr>
	      		<td><h4>No Telepon: 082233332222</h4></td>
	      		<td></td>
	      	</tr>
	      </table>
  		</div>
  		<div class="col-md-4">
	      <h3 align="center">Social Media</h3>
	      <div align="center">
	      	<i class="fa fa-facebook fa-5x" aria-hidden="true"></i> &nbsp;&nbsp;
		    <i class="fa fa-twitter fa-5x" aria-hidden="true"></i> &nbsp;&nbsp;
		    <i class="fa fa-google-plus fa-5x" aria-hidden="true"></i>
	      </div>
	      
  		</div> 
  		<div class="col-md-4">
	   	  <h3 align="center">Lorem Ipsum</h3>
	   	  <p align="justifiy">
	   	  	Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam animi saepe iste quas accusamus magnam, molestias voluptas suscipit! Id consequatur iste placeat aspernatur pariatur nisi doloremque quo tempore ipsa distinctio.
	   	  </p>
  		</div>
	</div>
	</div>
</div>

<script src="<?php echo base_url('assets/plugins/jquery/dist/jquery.min.js') ?>"></script>
<script src="<?php echo base_url('assets/plugins/bootstrap/dist/js/bootstrap.min.js')?>" ></script>
</body>
</html>