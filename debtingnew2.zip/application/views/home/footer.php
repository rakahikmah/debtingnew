	<div class="footer">
<div class="container-fluid">
	<div class="row">
		<div class="col-md-4">
	      <h3 align="center">Alamat Kami</h3>
	      <table class="table">
	      	<tr>
	      		<td><h4>Lokasi: Jalan Mawar No.47</h4></td>
	      		<td></td>
	      	</tr>
	      	<tr>
	      		<td><h4>No Telepon: 082233332222</h4></td>
	      		<td></td>
	      	</tr>
	      </table>
  		</div>
  		<div class="col-md-8"><br><br>
	   	  <h3 align="center">&copy; Copyright 2017 by 1.4.J</h3>
  		</div>
	</div>
	</div>
</div>

<script src="<?php echo base_url('assets/plugins/jquery/dist/jquery.min.js') ?>"></script>
<script src="<?php echo base_url('assets/plugins/bootstrap/dist/js/bootstrap.min.js')?>" ></script>
</body>
</html>